#ifndef _BDROID_BUILDCFG_H
#define _BDROID_BUILDCFG_H

#define BTM_DEF_LOCAL_NAME   "Lenovo P70"
// Disables read remote device feature
#define BTA_SKIP_BLE_READ_REMOTE_FEAT TRUE


/* Defined if the kernel does not have support for CLOCK_BOOTTIME_ALARM */
#define KERNEL_MISSING_CLOCK_BOOTTIME_ALARM TRUE
#endif
